# API Reference - All Endpoints & Responses

## Base URL
```
http://localhost:5000/api
```

---

## Authentication Endpoints

### 1. POST `/auth/signup`
**Create new user account**

**Request:**
```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "password123"
}
```

**Success Response (201):**
```json
{
  "success": true,
  "message": "User created successfully",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "_id": "507f1f77bcf86cd799439011",
    "name": "John Doe",
    "email": "john@example.com",
    "role": "user"
  }
}
```

**Error Response (400):**
```json
{
  "message": "Email already registered"
}
```

---

### 2. POST `/auth/login`
**Authenticate user and get JWT token**

**Request:**
```json
{
  "email": "admin@onewhite.com",
  "password": "admin123456"
}
```

**Success Response (200):**
```json
{
  "success": true,
  "message": "Login successful",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "_id": "507f1f77bcf86cd799439011",
    "name": "Admin User",
    "email": "admin@onewhite.com",
    "role": "admin"
  }
}
```

**Error Response (401):**
```json
{
  "message": "Invalid email or password"
}
```

---

## Product Endpoints

### 3. GET `/products`
**List all products with optional filtering**

**Query Parameters:**
- `search` (string) - Search in name/description
- `category` (string) - Filter by category
- `min` (number) - Minimum price
- `max` (number) - Maximum price
- `page` (number) - Page number (default: 1)
- `limit` (number) - Items per page (default: 12)

**Example Request:**
```
GET /products?search=handwash&category=Hand Care&min=100&max=200&page=1&limit=10
```

**Success Response (200):**
```json
{
  "success": true,
  "data": [
    {
      "_id": "507f1f77bcf86cd799439011",
      "name": "Premium Handwash",
      "description": "Gentle yet effective hand cleansing formula",
      "price": 150,
      "image": "handwash.jpeg",
      "category": "Hand Care",
      "stock": 50,
      "createdAt": "2024-01-15T10:30:00.000Z",
      "updatedAt": "2024-01-15T10:30:00.000Z"
    }
  ],
  "pagination": {
    "total": 45,
    "page": 1,
    "limit": 10,
    "pages": 5
  }
}
```

---

### 4. GET `/products/:id`
**Get single product by ID**

**Example Request:**
```
GET /products/507f1f77bcf86cd799439011
```

**Success Response (200):**
```json
{
  "success": true,
  "data": {
    "_id": "507f1f77bcf86cd799439011",
    "name": "Premium Handwash",
    "description": "Gentle yet effective hand cleansing formula",
    "price": 150,
    "image": "handwash.jpeg",
    "category": "Hand Care",
    "stock": 50,
    "createdAt": "2024-01-15T10:30:00.000Z",
    "updatedAt": "2024-01-15T10:30:00.000Z"
  }
}
```

**Error Response (404):**
```json
{
  "message": "Product not found"
}
```

---

### 5. GET `/products/featured`
**Get featured products**

**Success Response (200):**
```json
{
  "success": true,
  "data": [
    {
      "_id": "507f1f77bcf86cd799439011",
      "name": "Premium Handwash",
      "price": 150,
      "image": "handwash.jpeg",
      "stock": 50
    }
  ]
}
```

---

## Cart Endpoints (Protected - Requires JWT)

**All cart endpoints require:**
```
Header: Authorization: Bearer <JWT_TOKEN>
```

### 6. GET `/cart`
**Get user's shopping cart with product details**

**Success Response (200):**
```json
{
  "success": true,
  "data": {
    "items": [
      {
        "product": {
          "_id": "507f1f77bcf86cd799439011",
          "name": "Premium Handwash",
          "price": 150,
          "image": "handwash.jpeg"
        },
        "qty": 2,
        "subtotal": 300
      },
      {
        "product": {
          "_id": "507f1f77bcf86cd799439012",
          "name": "Phenyl Cleaner",
          "price": 120,
          "image": "phenyl.jpeg"
        },
        "qty": 1,
        "subtotal": 120
      }
    ],
    "itemsTotal": 420,
    "shippingPrice": 50,
    "taxPrice": 47,
    "totalPrice": 517
  }
}
```

**Error Response (401):**
```json
{
  "message": "No token provided"
}
```

---

### 7. POST `/cart`
**Add item to cart or update quantity (qty=0 to remove)**

**Request:**
```json
{
  "productId": "507f1f77bcf86cd799439011",
  "qty": 2
}
```

**Success Response (200):**
```json
{
  "success": true,
  "message": "Cart updated",
  "data": {
    "items": [
      {
        "product": {
          "_id": "507f1f77bcf86cd799439011",
          "name": "Premium Handwash",
          "price": 150,
          "image": "handwash.jpeg"
        },
        "qty": 2,
        "subtotal": 300
      }
    ],
    "itemsTotal": 300,
    "shippingPrice": 50,
    "taxPrice": 30,
    "totalPrice": 380
  }
}
```

**Error Response (404):**
```json
{
  "message": "Product not found"
}
```

---

### 8. PUT `/cart`
**Update multiple cart items at once**

**Request:**
```json
{
  "items": [
    { "productId": "507f1f77bcf86cd799439011", "qty": 3 },
    { "productId": "507f1f77bcf86cd799439012", "qty": 1 }
  ]
}
```

**Success Response (200):**
```json
{
  "success": true,
  "message": "Cart updated",
  "data": {
    "items": [
      {
        "product": {...},
        "qty": 3,
        "subtotal": 450
      },
      {
        "product": {...},
        "qty": 1,
        "subtotal": 120
      }
    ],
    "itemsTotal": 570,
    "shippingPrice": 50,
    "taxPrice": 62,
    "totalPrice": 682
  }
}
```

---

### 9. DELETE `/cart/:productId`
**Remove single item from cart**

**Example Request:**
```
DELETE /cart/507f1f77bcf86cd799439011
```

**Success Response (200):**
```json
{
  "success": true,
  "message": "Item removed from cart",
  "data": {
    "items": [
      {
        "product": {...},
        "qty": 1,
        "subtotal": 120
      }
    ],
    "itemsTotal": 120,
    "shippingPrice": 50,
    "taxPrice": 17,
    "totalPrice": 187
  }
}
```

---

## Order Endpoints (Protected - Requires JWT)

**All order endpoints require:**
```
Header: Authorization: Bearer <JWT_TOKEN>
```

### 10. POST `/orders`
**Create order from cart**

**Request:**
```json
{
  "shippingAddress": {
    "name": "John Doe",
    "address": "123 Main Street",
    "city": "New York",
    "postalCode": "10001",
    "country": "USA"
  },
  "paymentMethod": "credit_card"
}
```

**Success Response (201):**
```json
{
  "success": true,
  "message": "Order created successfully",
  "data": {
    "_id": "507f1f77bcf86cd799439013",
    "user": {
      "_id": "507f1f77bcf86cd799439011",
      "name": "John Doe",
      "email": "john@example.com"
    },
    "items": [
      {
        "product": {
          "_id": "507f1f77bcf86cd799439011",
          "name": "Premium Handwash",
          "price": 150,
          "image": "handwash.jpeg"
        },
        "qty": 2,
        "priceAtPurchase": 150
      }
    ],
    "shippingAddress": {
      "name": "John Doe",
      "address": "123 Main Street",
      "city": "New York",
      "postalCode": "10001",
      "country": "USA"
    },
    "paymentMethod": "credit_card",
    "itemsTotal": 300,
    "shippingPrice": 50,
    "taxPrice": 30,
    "totalPrice": 380,
    "status": "pending",
    "createdAt": "2024-01-15T10:30:00.000Z",
    "updatedAt": "2024-01-15T10:30:00.000Z"
  }
}
```

**Error Response (400):**
```json
{
  "message": "Insufficient stock for Premium Handwash"
}
```

---

### 11. GET `/orders`
**Get all orders for logged-in user**

**Success Response (200):**
```json
{
  "success": true,
  "data": [
    {
      "_id": "507f1f77bcf86cd799439013",
      "items": [
        {
          "product": {...},
          "qty": 2,
          "priceAtPurchase": 150
        }
      ],
      "itemsTotal": 300,
      "shippingPrice": 50,
      "taxPrice": 30,
      "totalPrice": 380,
      "status": "paid",
      "createdAt": "2024-01-15T10:30:00.000Z"
    }
  ]
}
```

---

### 12. GET `/orders/:id`
**Get specific order details**

**Example Request:**
```
GET /orders/507f1f77bcf86cd799439013
```

**Success Response (200):**
```json
{
  "success": true,
  "data": {
    "_id": "507f1f77bcf86cd799439013",
    "user": {
      "_id": "507f1f77bcf86cd799439011",
      "name": "John Doe"
    },
    "items": [
      {
        "product": {
          "_id": "507f1f77bcf86cd799439011",
          "name": "Premium Handwash",
          "price": 150
        },
        "qty": 2,
        "priceAtPurchase": 150
      }
    ],
    "shippingAddress": {
      "name": "John Doe",
      "address": "123 Main Street",
      "city": "New York",
      "postalCode": "10001",
      "country": "USA"
    },
    "itemsTotal": 300,
    "shippingPrice": 50,
    "taxPrice": 30,
    "totalPrice": 380,
    "status": "paid",
    "createdAt": "2024-01-15T10:30:00.000Z"
  }
}
```

**Error Response (403):**
```json
{
  "message": "Not authorized to view this order"
}
```

---

## Admin Endpoints (Protected - Admin Role Required)

**All admin endpoints require:**
```
Header: Authorization: Bearer <ADMIN_JWT_TOKEN>
```

### 13. POST `/admin/products`
**Create new product**

**Request:**
```json
{
  "name": "New Cleaning Product",
  "description": "Effective cleaning solution",
  "price": 180,
  "image": "new-product.jpeg",
  "category": "Home Care",
  "stock": 100
}
```

**Success Response (201):**
```json
{
  "success": true,
  "message": "Product created successfully",
  "data": {
    "_id": "507f1f77bcf86cd799439014",
    "name": "New Cleaning Product",
    "description": "Effective cleaning solution",
    "price": 180,
    "image": "new-product.jpeg",
    "category": "Home Care",
    "stock": 100,
    "createdAt": "2024-01-15T10:30:00.000Z",
    "updatedAt": "2024-01-15T10:30:00.000Z"
  }
}
```

---

### 14. PUT `/admin/products/:id`
**Update existing product**

**Request:**
```json
{
  "name": "Updated Product Name",
  "price": 190,
  "stock": 80
}
```

**Success Response (200):**
```json
{
  "success": true,
  "message": "Product updated successfully",
  "data": {
    "_id": "507f1f77bcf86cd799439014",
    "name": "Updated Product Name",
    "price": 190,
    "stock": 80
  }
}
```

---

### 15. DELETE `/admin/products/:id`
**Delete product**

**Example Request:**
```
DELETE /admin/products/507f1f77bcf86cd799439014
```

**Success Response (200):**
```json
{
  "success": true,
  "message": "Product deleted successfully"
}
```

---

### 16. GET `/admin/orders`
**Get all orders in system**

**Success Response (200):**
```json
{
  "success": true,
  "data": [
    {
      "_id": "507f1f77bcf86cd799439013",
      "user": {
        "_id": "507f1f77bcf86cd799439011",
        "name": "John Doe",
        "email": "john@example.com"
      },
      "items": [...],
      "totalPrice": 380,
      "status": "paid",
      "createdAt": "2024-01-15T10:30:00.000Z"
    }
  ]
}
```

---

## System Endpoints

### 17. GET `/health`
**Check if backend is running**

**Success Response (200):**
```json
{
  "status": "Backend is running"
}
```

---

## Error Responses

### Authentication Error (401)
```json
{
  "message": "Invalid or expired token"
}
```

### Authorization Error (403)
```json
{
  "message": "Forbidden: Admin access required"
}
```

### Not Found Error (404)
```json
{
  "message": "Route not found"
}
```

### Server Error (500)
```json
{
  "success": false,
  "message": "Internal server error"
}
```

---

## Response Status Codes

| Code | Meaning |
|------|---------|
| 200 | Success |
| 201 | Created |
| 400 | Bad Request |
| 401 | Unauthorized (no/invalid token) |
| 403 | Forbidden (insufficient permissions) |
| 404 | Not Found |
| 500 | Server Error |

---

## Token Format

All protected routes require:
```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

Token is obtained from `/auth/login` response and should be stored in `localStorage`:
```javascript
localStorage.setItem('token', response.token);
```

To use in requests:
```javascript
fetch('/api/cart', {
  headers: {
    'Authorization': `Bearer ${localStorage.getItem('token')}`
  }
})
```

---

## Rate Limiting

Currently not implemented. Consider adding for production.

---

## CORS

Frontend origin must be configured in `.env`:
```
FRONTEND_URL=http://localhost:3000
```

---

## Pagination

Products endpoint supports:
- `page` (default: 1)
- `limit` (default: 12)

Response includes:
```json
{
  "pagination": {
    "total": 45,
    "page": 1,
    "limit": 12,
    "pages": 4
  }
}
```

---

## Seeded Test Data

### Products (8 total)
- Premium Handwash (Rs 150)
- Handwash Variant 1 (Rs 160)
- Handwash Variant 2 (Rs 160)
- Phenyl Cleaner (Rs 120)
- Harpic Toilet Cleaner (Rs 180)
- Drain Cleaner (Rs 200)
- Floor & Surface Cleaner (Rs 140)
- Mirror Cleaner (Rs 130)

### Users
- Admin: admin@onewhite.com / admin123456
- Customer: customer@onewhite.com / customer123456

---

## Complete cURL Examples

### Health Check
```bash
curl http://localhost:5000/api/health
```

### Signup
```bash
curl -X POST http://localhost:5000/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"name":"John","email":"john@test.com","password":"pass123"}'
```

### Login
```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@onewhite.com","password":"admin123456"}'
```

### Get Products (with filters)
```bash
curl "http://localhost:5000/api/products?search=handwash&limit=5&page=1"
```

### Get Cart (replace TOKEN)
```bash
curl -H "Authorization: Bearer TOKEN" \
  http://localhost:5000/api/cart
```

### Add to Cart
```bash
curl -X POST http://localhost:5000/api/cart \
  -H "Authorization: Bearer TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"productId":"PRODUCT_ID","qty":2}'
```

### Create Order
```bash
curl -X POST http://localhost:5000/api/orders \
  -H "Authorization: Bearer TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "shippingAddress": {
      "name": "John Doe",
      "address": "123 Main St",
      "city": "NYC",
      "postalCode": "10001",
      "country": "USA"
    },
    "paymentMethod": "credit_card"
  }'
```

---

End of API Reference
