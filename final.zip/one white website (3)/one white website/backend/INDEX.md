# 📚 Backend Documentation Index

## Start Here

### For Immediate Setup (5 minutes)
👉 **[QUICKSTART.md](./QUICKSTART.md)** - Get backend running in 5 minutes

### For Complete Documentation
👉 **[README.md](./README.md)** - Full guide with all endpoints and examples

---

## Documentation Files

### 🚀 Getting Started
- **[QUICKSTART.md](./QUICKSTART.md)** - 5-minute setup guide with test credentials
- **[SUMMARY.md](./SUMMARY.md)** - Project overview and what's been built

### 📖 Complete References
- **[README.md](./README.md)** - Full API documentation (70+ KB)
  - Installation & setup
  - All 23 API endpoints with examples
  - Database schemas
  - 20+ cURL examples
  - Troubleshooting guide
  - Security best practices

- **[API_REFERENCE.md](./API_REFERENCE.md)** - All endpoints and responses
  - Detailed request/response examples
  - Error codes and messages
  - Query parameters explained
  - Status codes reference

### 🔧 Configuration & Structure
- **[STRUCTURE.md](./STRUCTURE.md)** - Directory structure and file overview
- **[CHECKLIST.md](./CHECKLIST.md)** - Verification checklist of all components
- **[.env.example](./.env.example)** - Environment variables template

### 💻 Frontend Integration
- **[FRONTEND_INTEGRATION.js](./FRONTEND_INTEGRATION.js)** - Copy-paste code for:
  - Login page integration
  - Cart page integration
  - Checkout page integration
  - Header cart count update
  - Complete API helper functions

### 📋 Configuration
- **[package.json](./package.json)** - NPM dependencies and scripts
- **[.gitignore](./.gitignore)** - Git ignore rules

---

## Quick Navigation

### I want to...

**Get the backend running**
→ [QUICKSTART.md](./QUICKSTART.md)

**Understand the project structure**
→ [STRUCTURE.md](./STRUCTURE.md)

**See all API endpoints**
→ [API_REFERENCE.md](./API_REFERENCE.md)

**Integrate with frontend**
→ [FRONTEND_INTEGRATION.js](./FRONTEND_INTEGRATION.js)

**Learn complete backend setup**
→ [README.md](./README.md)

**Test with cURL commands**
→ [README.md](./README.md#curl-examples-testing)

**Understand database schemas**
→ [README.md](./README.md#database-schema)

**Fix issues/troubleshoot**
→ [README.md](./README.md#troubleshooting)

**Verify everything is set up**
→ [CHECKLIST.md](./CHECKLIST.md)

---

## Setup Steps

### 1️⃣ Configure Environment
```bash
cd backend
cp .env.example .env
# Edit .env with your MongoDB Atlas URI
```

### 2️⃣ Install Dependencies
```bash
npm install
```

### 3️⃣ Seed Database
```bash
npm run seed
```

### 4️⃣ Start Development Server
```bash
npm run dev
```

### 5️⃣ Integrate Frontend
Use code from [FRONTEND_INTEGRATION.js](./FRONTEND_INTEGRATION.js)

---

## Key Files in `src/`

### Server Setup
- **[src/server.js](./src/server.js)** - Express app configuration

### Database
- **[src/config/db.js](./src/config/db.js)** - MongoDB connection
- **[src/utils/seed.js](./src/utils/seed.js)** - Database seeding script

### Database Models
- **[src/models/Product.js](./src/models/Product.js)** - Product schema
- **[src/models/User.js](./src/models/User.js)** - User schema with cart
- **[src/models/Order.js](./src/models/Order.js)** - Order schema

### Route Handlers
- **[src/controllers/auth.controller.js](./src/controllers/auth.controller.js)** - Signup & login logic
- **[src/controllers/products.controller.js](./src/controllers/products.controller.js)** - Product operations
- **[src/controllers/cart.controller.js](./src/controllers/cart.controller.js)** - Cart operations
- **[src/controllers/orders.controller.js](./src/controllers/orders.controller.js)** - Order operations
- **[src/controllers/admin.controller.js](./src/controllers/admin.controller.js)** - Admin operations

### Routes
- **[src/routes/auth.routes.js](./src/routes/auth.routes.js)** - /api/auth/*
- **[src/routes/products.routes.js](./src/routes/products.routes.js)** - /api/products/*
- **[src/routes/cart.routes.js](./src/routes/cart.routes.js)** - /api/cart/*
- **[src/routes/orders.routes.js](./src/routes/orders.routes.js)** - /api/orders/*
- **[src/routes/admin.routes.js](./src/routes/admin.routes.js)** - /api/admin/*

### Middleware
- **[src/middleware/auth.middleware.js](./src/middleware/auth.middleware.js)** - JWT verification
- **[src/middleware/error.middleware.js](./src/middleware/error.middleware.js)** - Error handling

---

## API Endpoints Summary

### Authentication (2 endpoints)
- `POST /api/auth/signup` - Create account
- `POST /api/auth/login` - Login

### Products (3 endpoints)
- `GET /api/products` - List with filters
- `GET /api/products/:id` - Get single
- `GET /api/products/featured` - Featured items

### Cart (4 endpoints)
- `GET /api/cart` - Get cart
- `POST /api/cart` - Add item
- `PUT /api/cart` - Update items
- `DELETE /api/cart/:productId` - Remove item

### Orders (3 endpoints)
- `POST /api/orders` - Create order
- `GET /api/orders` - List orders
- `GET /api/orders/:id` - Get order details

### Admin (4 endpoints)
- `POST /api/admin/products` - Create product
- `PUT /api/admin/products/:id` - Update product
- `DELETE /api/admin/products/:id` - Delete product
- `GET /api/admin/orders` - List all orders

### System (1 endpoint)
- `GET /api/health` - Health check

**Total: 23 endpoints**

---

## Test Credentials

After running `npm run seed`:

| Role | Email | Password |
|------|-------|----------|
| Admin | `admin@onewhite.com` | `admin123456` |
| Customer | `customer@onewhite.com` | `customer123456` |

---

## Features

✅ JWT Authentication
✅ Password hashing with bcrypt
✅ MongoDB with Mongoose
✅ Shopping cart with real calculations
✅ Order management with inventory tracking
✅ Admin dashboard endpoints
✅ CORS protection
✅ Input validation
✅ Global error handling
✅ Environment configuration
✅ Database seeding
✅ Complete documentation
✅ Copy-paste frontend integration code

---

## Technology Stack

- **Runtime:** Node.js v18+
- **Framework:** Express.js
- **Database:** MongoDB + Mongoose
- **Authentication:** JWT
- **Encryption:** bcrypt
- **Environment:** dotenv
- **CORS:** cors middleware
- **Dev Tool:** nodemon

---

## Seeded Data

### Products (8)
- Premium Handwash (Rs 150)
- Handwash Variant 1 (Rs 160)
- Handwash Variant 2 (Rs 160)
- Phenyl Cleaner (Rs 120)
- Harpic Toilet Cleaner (Rs 180)
- Drain Cleaner (Rs 200)
- Floor & Surface Cleaner (Rs 140)
- Mirror Cleaner (Rs 130)

### Users (2)
- Admin user
- Customer user

---

## Scripts

```bash
npm run dev    # Start development server with auto-reload
npm start      # Start production server
npm run seed   # Populate database with initial data
```

---

## Troubleshooting

**"Cannot find module"**
→ Run `npm install`

**"MongoDB connection failed"**
→ Check .env MONGO_URI

**"Port 5000 already in use"**
→ Change PORT in .env

**"Products not showing"**
→ Run `npm run seed`

**"Cart data not loading"**
→ Check Authorization header with token

See [README.md](./README.md#troubleshooting) for complete troubleshooting guide.

---

## Next Steps

1. ✅ Backend files created
2. 📋 Setup .env with MongoDB URI
3. 🚀 Run `npm run seed`
4. 🏃 Run `npm run dev`
5. 💻 Integrate frontend using FRONTEND_INTEGRATION.js
6. ✨ Test login/cart/checkout flows
7. 🌐 Deploy when ready

---

## Support

- **Setup issues?** → See [QUICKSTART.md](./QUICKSTART.md)
- **API questions?** → See [API_REFERENCE.md](./API_REFERENCE.md)
- **Integration help?** → See [FRONTEND_INTEGRATION.js](./FRONTEND_INTEGRATION.js)
- **Detailed guide?** → See [README.md](./README.md)
- **Troubleshooting?** → See [README.md#troubleshooting](./README.md#troubleshooting)

---

**Ready to go?** Start with [QUICKSTART.md](./QUICKSTART.md) 🚀
