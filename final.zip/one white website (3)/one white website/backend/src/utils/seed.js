/**
 * Seed Script - Populate initial product data and create admin user
 * Run with: npm run seed
 */

require('dotenv').config();
const mongoose = require('mongoose');
const Product = require('../models/Product');
const User = require('../models/User');

const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log('MongoDB Connected');
  } catch (error) {
    console.error('Error connecting to MongoDB:', error);
    process.exit(1);
  }
};

const seedDatabase = async () => {
  try {
    // Clear existing data
    await Product.deleteMany({});
    await User.deleteMany({});
    console.log('Cleared existing data');

    // Product data with exact image filenames from frontend
    const products = [
      // Handwash Gel 230ml
      {
        name: 'Handwash Gel - Peach',
        description: 'Premium gel formula for soft and clean hands with peach fragrance',
        price: 230,
        image: 'handwash 1.1.jpeg',
        category: 'Hand Care',
        stock: 50,
      },
      {
        name: 'Handwash Gel - Blueberry',
        description: 'Premium gel formula for soft and clean hands with blueberry fragrance',
        price: 230,
        image: 'handwash 1.2.jpeg',
        category: 'Hand Care',
        stock: 50,
      },
      {
        name: 'Handwash Gel - Lavender',
        description: 'Premium gel formula for soft and clean hands with lavender fragrance',
        price: 230,
        image: 'handwash 1.3.jpeg',
        category: 'Hand Care',
        stock: 50,
      },
      {
        name: 'Handwash Gel - Apple',
        description: 'Premium gel formula for soft and clean hands with apple fragrance',
        price: 230,
        image: 'handwash 1.4.jpeg',
        category: 'Hand Care',
        stock: 50,
      },
      // Handwash Pearl 250ml
      {
        name: 'Handwash Pearl - Amazon',
        description: 'Luxurious pearl formula for smooth and glowing hands with Amazon fragrance',
        price: 250,
        image: 'handwash 2.1.jpeg',
        category: 'Hand Care',
        stock: 45,
      },
      {
        name: 'Handwash Pearl - Tangerine',
        description: 'Luxurious pearl formula for smooth and glowing hands with Tangerine fragrance',
        price: 250,
        image: 'handwash 2.2.jpeg',
        category: 'Hand Care',
        stock: 45,
      },
      {
        name: 'Handwash Pearl - Orchid',
        description: 'Luxurious pearl formula for smooth and glowing hands with Orchid fragrance',
        price: 250,
        image: 'handwash 2.3.jpeg',
        category: 'Hand Care',
        stock: 45,
      },
      {
        name: 'Handwash Pearl - Aqua IRIS',
        description: 'Luxurious pearl formula for smooth and glowing hands with Aqua IRIS fragrance',
        price: 250,
        image: 'handwash 2.4.jpeg',
        category: 'Hand Care',
        stock: 45,
      },
      // Floor & Surface Cleaners
      {
        name: 'Phenyl Cleaner',
        description: 'Strong disinfectant phenyl for floors and surfaces',
        price: 120,
        image: 'phenyl.jpeg',
        category: 'Home Care',
        stock: 60,
      },
      {
        name: 'Mirror Cleaner',
        description: 'Streak-free mirror and glass cleaner spray',
        price: 130,
        image: 'mirror cleaner.jpeg',
        category: 'Home Care',
        stock: 45,
      },
      {
        name: 'Drain Cleaner',
        description: 'Effective drain cleaning solution for unclogging pipes',
        price: 200,
        image: 'drain cleaner.jpeg',
        category: 'Plumbing',
        stock: 30,
      },
      {
        name: 'Harpic Toilet Cleaner',
        description: 'Powerful toilet bowl cleaner with bleach action',
        price: 180,
        image: 'harpic.png',
        category: 'Bathroom Care',
        stock: 35,
      },
    ];

    // Insert products
    const insertedProducts = await Product.insertMany(products);
    console.log(`✓ Seeded ${insertedProducts.length} products`);

    // Create admin user
    const adminUser = new User({
      name: 'Admin User',
      email: 'admin@onewhite.com',
      password: 'admin123456', // Will be hashed by User model pre-save hook
      role: 'admin',
    });

    await adminUser.save();
    console.log(`✓ Created admin user: admin@onewhite.com (password: admin123456)`);

    // Create test user
    const testUser = new User({
      name: 'Test Customer',
      email: 'customer@onewhite.com',
      password: 'customer123456',
      role: 'user',
    });

    await testUser.save();
    console.log(`✓ Created test user: customer@onewhite.com (password: customer123456)`);

    console.log('\n✓ Database seeded successfully!');
    console.log('\nTest Credentials:');
    console.log('Admin: admin@onewhite.com / admin123456');
    console.log('Customer: customer@onewhite.com / customer123456');

    process.exit(0);
  } catch (error) {
    console.error('Error seeding database:', error);
    process.exit(1);
  }
};

// Run seed
connectDB().then(() => {
  seedDatabase();
});
