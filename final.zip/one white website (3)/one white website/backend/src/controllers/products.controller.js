const Product = require('../models/Product');

// Get all products with optional filtering and pagination
exports.getProducts = async (req, res) => {
  try {
    const {
      search = '',
      category = '',
      min = 0,
      max = Infinity,
      page = 1,
      limit = 12,
    } = req.query;

    // Build query filters
    const filters = {
      price: { $gte: min, $lte: max },
    };

    if (search) {
      filters.$or = [
        { name: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
      ];
    }

    if (category) {
      filters.category = { $regex: category, $options: 'i' };
    }

    // Calculate pagination
    const pageNum = parseInt(page, 10) || 1;
    const pageSize = parseInt(limit, 10) || 12;
    const skip = (pageNum - 1) * pageSize;

    // Query products
    const products = await Product.find(filters)
      .skip(skip)
      .limit(pageSize)
      .sort({ createdAt: -1 });

    // Get total count for pagination
    const total = await Product.countDocuments(filters);

    res.status(200).json({
      success: true,
      data: products,
      pagination: {
        total,
        page: pageNum,
        limit: pageSize,
        pages: Math.ceil(total / pageSize),
      },
    });
  } catch (error) {
    console.error('Get products error:', error);
    res
      .status(500)
      .json({ message: 'Failed to fetch products', error: error.message });
  }
};

// Get single product by ID
exports.getProductById = async (req, res) => {
  try {
    const { id } = req.params;

    const product = await Product.findById(id);
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    res.status(200).json({
      success: true,
      data: product,
    });
  } catch (error) {
    console.error('Get product error:', error);
    res
      .status(500)
      .json({ message: 'Failed to fetch product', error: error.message });
  }
};

// Get featured products (optional)
exports.getFeaturedProducts = async (req, res) => {
  try {
    const products = await Product.find().limit(6).sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      data: products,
    });
  } catch (error) {
    console.error('Get featured products error:', error);
    res.status(500).json({
      message: 'Failed to fetch featured products',
      error: error.message,
    });
  }
};
