const User = require('../models/User');
const Product = require('../models/Product');

// Get user's cart with populated product details
exports.getCart = async (req, res) => {
  try {
    const userId = req.user.userId;

    // Find user and populate cart with product details
    const user = await User.findById(userId).populate('cart.product');

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Calculate cart totals
    let itemsTotal = 0;
    const items = user.cart.map((item) => {
      const subtotal = item.product.price * item.qty;
      itemsTotal += subtotal;
      return {
        product: item.product,
        qty: item.qty,
        subtotal,
      };
    });

    // Calculate shipping and tax (fixed amounts for demo)
    const shippingPrice = itemsTotal > 0 ? 50 : 0;
    const taxPrice = Math.round(itemsTotal * 0.1); // 10% tax
    const totalPrice = itemsTotal + shippingPrice + taxPrice;

    res.status(200).json({
      success: true,
      data: {
        items,
        itemsTotal,
        shippingPrice,
        taxPrice,
        totalPrice,
      },
    });
  } catch (error) {
    console.error('Get cart error:', error);
    res.status(500).json({ message: 'Failed to fetch cart', error: error.message });
  }
};

// Add or update item in cart
exports.addToCart = async (req, res) => {
  try {
    const userId = req.user.userId;
    const { productId, qty } = req.body;

    // Validate input
    if (!productId || !qty) {
      return res
        .status(400)
        .json({ message: 'Please provide productId and qty' });
    }

    // Check if product exists
    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    // Find user
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Check if item already in cart
    const existingItem = user.cart.find(
      (item) => item.product.toString() === productId
    );

    if (existingItem) {
      // Update quantity if qty = 0, remove item; otherwise update
      if (qty <= 0) {
        user.cart = user.cart.filter(
          (item) => item.product.toString() !== productId
        );
      } else {
        existingItem.qty = qty;
      }
    } else {
      // Add new item to cart
      if (qty > 0) {
        user.cart.push({ product: productId, qty });
      }
    }

    await user.save();

    // Return updated cart with populated data
    const updatedUser = await User.findById(userId).populate('cart.product');

    let itemsTotal = 0;
    const items = updatedUser.cart.map((item) => {
      const subtotal = item.product.price * item.qty;
      itemsTotal += subtotal;
      return {
        product: item.product,
        qty: item.qty,
        subtotal,
      };
    });

    const shippingPrice = itemsTotal > 0 ? 50 : 0;
    const taxPrice = Math.round(itemsTotal * 0.1);
    const totalPrice = itemsTotal + shippingPrice + taxPrice;

    res.status(200).json({
      success: true,
      message: 'Cart updated',
      data: {
        items,
        itemsTotal,
        shippingPrice,
        taxPrice,
        totalPrice,
      },
    });
  } catch (error) {
    console.error('Add to cart error:', error);
    res
      .status(500)
      .json({ message: 'Failed to add to cart', error: error.message });
  }
};

// Update multiple items in cart
exports.updateCart = async (req, res) => {
  try {
    const userId = req.user.userId;
    const { items } = req.body; // Array of { productId, qty }

    if (!Array.isArray(items)) {
      return res
        .status(400)
        .json({ message: 'Items must be an array of { productId, qty }' });
    }

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Update cart with new items array
    user.cart = [];
    for (const item of items) {
      const { productId, qty } = item;

      // Validate product exists
      const product = await Product.findById(productId);
      if (!product) {
        return res
          .status(404)
          .json({ message: `Product ${productId} not found` });
      }

      if (qty > 0) {
        user.cart.push({ product: productId, qty });
      }
    }

    await user.save();

    // Return updated cart
    const updatedUser = await User.findById(userId).populate('cart.product');

    let itemsTotal = 0;
    const cartItems = updatedUser.cart.map((item) => {
      const subtotal = item.product.price * item.qty;
      itemsTotal += subtotal;
      return {
        product: item.product,
        qty: item.qty,
        subtotal,
      };
    });

    const shippingPrice = itemsTotal > 0 ? 50 : 0;
    const taxPrice = Math.round(itemsTotal * 0.1);
    const totalPrice = itemsTotal + shippingPrice + taxPrice;

    res.status(200).json({
      success: true,
      message: 'Cart updated',
      data: {
        items: cartItems,
        itemsTotal,
        shippingPrice,
        taxPrice,
        totalPrice,
      },
    });
  } catch (error) {
    console.error('Update cart error:', error);
    res
      .status(500)
      .json({ message: 'Failed to update cart', error: error.message });
  }
};

// Remove single item from cart
exports.removeFromCart = async (req, res) => {
  try {
    const userId = req.user.userId;
    const { productId } = req.params;

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Remove item from cart
    user.cart = user.cart.filter(
      (item) => item.product.toString() !== productId
    );

    await user.save();

    // Return updated cart
    const updatedUser = await User.findById(userId).populate('cart.product');

    let itemsTotal = 0;
    const items = updatedUser.cart.map((item) => {
      const subtotal = item.product.price * item.qty;
      itemsTotal += subtotal;
      return {
        product: item.product,
        qty: item.qty,
        subtotal,
      };
    });

    const shippingPrice = itemsTotal > 0 ? 50 : 0;
    const taxPrice = Math.round(itemsTotal * 0.1);
    const totalPrice = itemsTotal + shippingPrice + taxPrice;

    res.status(200).json({
      success: true,
      message: 'Item removed from cart',
      data: {
        items,
        itemsTotal,
        shippingPrice,
        taxPrice,
        totalPrice,
      },
    });
  } catch (error) {
    console.error('Remove from cart error:', error);
    res.status(500).json({
      message: 'Failed to remove from cart',
      error: error.message,
    });
  }
};
