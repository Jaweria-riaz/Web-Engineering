const Order = require('../models/Order');
const User = require('../models/User');
const Product = require('../models/Product');

// Create new order from cart
exports.createOrder = async (req, res) => {
  try {
    const userId = req.user.userId;
    const { shippingAddress, shippingPhone, paymentMethod } = req.body;

    // Validate input
    if (!shippingAddress || !paymentMethod) {
      return res.status(400).json({
        message: 'Please provide shippingAddress and paymentMethod',
      });
    }

    const user = await User.findById(userId).populate('cart.product');

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    if (user.cart.length === 0) {
      return res.status(400).json({ message: 'Cart is empty' });
    }

    // Prepare order items and check stock
    const items = [];
    let itemsTotal = 0;

    for (const cartItem of user.cart) {
      const product = cartItem.product;

      // Check stock availability
      if (product.stock < cartItem.qty) {
        return res.status(400).json({
          message: `Insufficient stock for ${product.name}`,
        });
      }

      items.push({
        product: product._id,
        qty: cartItem.qty,
        priceAtPurchase: product.price,
      });

      itemsTotal += product.price * cartItem.qty;
    }

    // Calculate totals (no tax for now)
    const shippingPrice = 200;
    const taxPrice = 0;
    const totalPrice = itemsTotal + shippingPrice + taxPrice;

    // Create order with simplified shippingAddress
    const order = new Order({
      user: userId,
      items,
      shippingAddress: {
        name: user.name,
        address: shippingAddress,
        city: 'Default',
        postalCode: '00000',
        country: 'Pakistan',
      },
      paymentMethod,
      itemsTotal,
      shippingPrice,
      taxPrice,
      totalPrice,
      status: 'pending',
    });

    await order.save();

    // Reduce product stock
    for (const cartItem of user.cart) {
      await Product.findByIdAndUpdate(cartItem.product._id, {
        $inc: { stock: -cartItem.qty },
      });
    }

    // Clear user cart
    user.cart = [];

    // Add order to user's orders array
    user.orders.push(order._id);
    await user.save();

    // Populate order for response
    const populatedOrder = await Order.findById(order._id)
      .populate('user')
      .populate('items.product');

    res.status(201).json({
      success: true,
      message: 'Order created successfully',
      data: populatedOrder,
    });
  } catch (error) {
    console.error('Create order error:', error);
    res.status(500).json({
      message: 'Failed to create order',
      error: error.message,
    });
  }
};

// Get user's orders
exports.getUserOrders = async (req, res) => {
  try {
    const userId = req.user.userId;

    const orders = await Order.find({ user: userId })
      .populate('items.product')
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      data: orders,
    });
  } catch (error) {
    console.error('Get user orders error:', error);
    res.status(500).json({
      message: 'Failed to fetch orders',
      error: error.message,
    });
  }
};

// Get order details by ID
exports.getOrderById = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.userId;

    const order = await Order.findById(id)
      .populate('user')
      .populate('items.product');

    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    // Ensure order belongs to logged-in user (or is admin)
    if (
      order.user._id.toString() !== userId &&
      req.user.role !== 'admin'
    ) {
      return res
        .status(403)
        .json({ message: 'Not authorized to view this order' });
    }

    res.status(200).json({
      success: true,
      data: order,
    });
  } catch (error) {
    console.error('Get order error:', error);
    res.status(500).json({
      message: 'Failed to fetch order',
      error: error.message,
    });
  }
};
