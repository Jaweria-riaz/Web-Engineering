const express = require('express');
const {
  createProduct,
  updateProduct,
  deleteProduct,
  getAllOrders,
} = require('../controllers/admin.controller');
const { authMiddleware, adminMiddleware } = require('../middleware/auth.middleware');

const router = express.Router();

// All admin routes require authentication and admin role
router.use(authMiddleware, adminMiddleware);

// POST /api/admin/products - Create product
router.post('/products', createProduct);

// PUT /api/admin/products/:id - Update product
router.put('/products/:id', updateProduct);

// DELETE /api/admin/products/:id - Delete product
router.delete('/products/:id', deleteProduct);

// GET /api/admin/orders - Get all orders
router.get('/orders', getAllOrders);

module.exports = router;
