const express = require('express');
const {
  getProducts,
  getProductById,
  getFeaturedProducts,
} = require('../controllers/products.controller');

const router = express.Router();

// GET /api/products - List products with filtering and pagination
router.get('/', getProducts);

// GET /api/products/featured - Get featured products
router.get('/featured', getFeaturedProducts);

// GET /api/products/:id - Get single product
router.get('/:id', getProductById);

module.exports = router;
