const express = require('express');
const {
  createOrder,
  getUserOrders,
  getOrderById,
} = require('../controllers/orders.controller');
const { authMiddleware } = require('../middleware/auth.middleware');

const router = express.Router();

// All order routes require authentication
router.use(authMiddleware);

// POST /api/orders - Create new order
router.post('/', createOrder);

// GET /api/orders - Get user's orders
router.get('/', getUserOrders);

// GET /api/orders/:id - Get order details
router.get('/:id', getOrderById);

module.exports = router;
