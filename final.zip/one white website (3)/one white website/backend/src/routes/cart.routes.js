const express = require('express');
const {
  getCart,
  addToCart,
  updateCart,
  removeFromCart,
} = require('../controllers/cart.controller');
const { authMiddleware } = require('../middleware/auth.middleware');

const router = express.Router();

// All cart routes require authentication
router.use(authMiddleware);

// GET /api/cart - Get user's cart
router.get('/', getCart);

// POST /api/cart - Add/update item in cart
router.post('/', addToCart);

// PUT /api/cart - Update multiple items
router.put('/', updateCart);

// DELETE /api/cart/:productId - Remove item from cart
router.delete('/:productId', removeFromCart);

module.exports = router;
