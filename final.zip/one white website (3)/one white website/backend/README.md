# One White E-Commerce Backend API

A complete Node.js/Express backend for the One White e-commerce platform with MongoDB, JWT authentication, and full cart & order management.

## Features

✅ **User Authentication** - JWT-based signup and login  
✅ **Product Catalog** - List, search, filter, and paginate products  
✅ **Shopping Cart** - Add, update, remove items with real-time calculations  
✅ **Orders & Checkout** - Place orders with inventory management  
✅ **Admin Panel Ready** - Product and order management endpoints  
✅ **Secure** - Password hashing with bcrypt, JWT tokens with expiry  
✅ **CORS Enabled** - Seamless frontend integration  

## Tech Stack

- **Runtime:** Node.js v18+
- **Framework:** Express.js
- **Database:** MongoDB with Mongoose
- **Authentication:** JWT (JSON Web Tokens)
- **Security:** bcrypt for password hashing
- **Environment:** dotenv for config management
- **Dev Tool:** nodemon for auto-reload

## Project Structure

```
backend/
├── package.json
├── .env.example
├── .gitignore
└── src/
    ├── server.js                 # Main Express app
    ├── config/
    │   └── db.js                # MongoDB connection
    ├── models/
    │   ├── Product.js           # Product schema
    │   ├── User.js              # User schema with cart
    │   └── Order.js             # Order schema
    ├── routes/
    │   ├── auth.routes.js       # Auth endpoints
    │   ├── products.routes.js   # Product endpoints
    │   ├── cart.routes.js       # Cart endpoints
    │   ├── orders.routes.js     # Order endpoints
    │   └── admin.routes.js      # Admin endpoints
    ├── controllers/
    │   ├── auth.controller.js
    │   ├── products.controller.js
    │   ├── cart.controller.js
    │   ├── orders.controller.js
    │   └── admin.controller.js
    ├── middleware/
    │   ├── auth.middleware.js   # JWT verification
    │   └── error.middleware.js  # Global error handler
    └── utils/
        └── seed.js              # Database seeding script
```

## Installation & Setup

### 1. Prerequisites
- Node.js v18+ installed
- MongoDB Atlas account (free tier available)
- Frontend running on `http://localhost:3000` (or update FRONTEND_URL)

### 2. Clone & Install

```bash
# Navigate to backend folder
cd backend

# Copy environment file
cp .env.example .env

# Install dependencies
npm install
```

### 3. Configure Environment Variables

Edit `.env` and add your MongoDB Atlas connection:

```env
PORT=5000
MONGO_URI=mongodb+srv://username:password@cluster0.xxxxx.mongodb.net/onewhite?retryWrites=true&w=majority
JWT_SECRET=your_secret_key_change_in_production
JWT_EXPIRE=7d
FRONTEND_URL=http://localhost:3000
NODE_ENV=development
```

**Get MongoDB Atlas URI:**
1. Go to [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)
2. Create a free cluster
3. Create a database user
4. Click "Connect" → "Connect your application"
5. Copy the connection string and replace `<password>` with your password

### 4. Seed Initial Data

```bash
npm run seed
```

This creates:
- 8 products with exact image filenames matching your frontend
- Admin user: `admin@onewhite.com` / `admin123456`
- Test user: `customer@onewhite.com` / `customer123456`

### 5. Start Development Server

```bash
npm run dev
```

Server runs on `http://localhost:5000`

Check health: `http://localhost:5000/api/health`

---

## API Endpoints

### Authentication

#### **POST** `/api/auth/signup`
Create new user account
```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "password123"
}
```
Response: `{ token, user }`

#### **POST** `/api/auth/login`
Login user
```json
{
  "email": "admin@onewhite.com",
  "password": "admin123456"
}
```
Response: `{ token, user }`

---

### Products

#### **GET** `/api/products`
List products with optional filters
```
GET /api/products?search=handwash&category=Hand Care&min=100&max=200&page=1&limit=12
```
Response: `{ data: [], pagination: { total, page, pages } }`

#### **GET** `/api/products/:id`
Get single product
```
GET /api/products/507f1f77bcf86cd799439011
```

#### **GET** `/api/products/featured`
Get featured products

---

### Cart (Protected - Requires JWT)

#### **GET** `/api/cart`
Get user's cart with populated product details
```bash
curl -H "Authorization: Bearer YOUR_TOKEN" http://localhost:5000/api/cart
```
Response:
```json
{
  "items": [
    {
      "product": { "_id": "...", "name": "Handwash", "price": 150, "image": "handwash.jpeg" },
      "qty": 2,
      "subtotal": 300
    }
  ],
  "itemsTotal": 300,
  "shippingPrice": 50,
  "taxPrice": 30,
  "totalPrice": 380
}
```

#### **POST** `/api/cart`
Add or update item (qty=0 to remove)
```json
{
  "productId": "507f1f77bcf86cd799439011",
  "qty": 2
}
```

#### **PUT** `/api/cart`
Update multiple items
```json
{
  "items": [
    { "productId": "507f1f77bcf86cd799439011", "qty": 3 },
    { "productId": "507f1f77bcf86cd799439012", "qty": 1 }
  ]
}
```

#### **DELETE** `/api/cart/:productId`
Remove item from cart

---

### Orders (Protected)

#### **POST** `/api/orders`
Create order from cart
```json
{
  "shippingAddress": {
    "name": "John Doe",
    "address": "123 Main St",
    "city": "New York",
    "postalCode": "10001",
    "country": "USA"
  },
  "paymentMethod": "credit_card"
}
```
Response: `{ order with items, totals, timestamps }`

#### **GET** `/api/orders`
Get user's orders

#### **GET** `/api/orders/:id`
Get order details

---

### Admin Routes (Protected - Admin Role Required)

#### **POST** `/api/admin/products`
Create product
```json
{
  "name": "New Product",
  "description": "Description here",
  "price": 150,
  "image": "product.jpeg",
  "category": "Category Name",
  "stock": 50
}
```

#### **PUT** `/api/admin/products/:id`
Update product

#### **DELETE** `/api/admin/products/:id`
Delete product

#### **GET** `/api/admin/orders`
Get all orders (for admin)

---

## Frontend Integration

### 1. Create API Config File

Create `js/api.js` in your frontend:

```javascript
// API configuration
const API_BASE_URL = 'http://localhost:5000/api';

const API = {
  // Auth
  signup: (name, email, password) =>
    fetch(`${API_BASE_URL}/auth/signup`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password })
    }).then(r => r.json()),

  login: (email, password) =>
    fetch(`${API_BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    }).then(r => r.json()),

  // Products
  getProducts: (filters = {}) => {
    const params = new URLSearchParams(filters);
    return fetch(`${API_BASE_URL}/products?${params}`).then(r => r.json());
  },

  getProduct: (id) =>
    fetch(`${API_BASE_URL}/products/${id}`).then(r => r.json()),

  // Cart
  getCart: (token) =>
    fetch(`${API_BASE_URL}/cart`, {
      headers: { Authorization: `Bearer ${token}` }
    }).then(r => r.json()),

  addToCart: (token, productId, qty) =>
    fetch(`${API_BASE_URL}/cart`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({ productId, qty })
    }).then(r => r.json()),

  removeFromCart: (token, productId) =>
    fetch(`${API_BASE_URL}/cart/${productId}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` }
    }).then(r => r.json()),

  // Orders
  createOrder: (token, shippingAddress, paymentMethod) =>
    fetch(`${API_BASE_URL}/orders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({ shippingAddress, paymentMethod })
    }).then(r => r.json()),

  getOrders: (token) =>
    fetch(`${API_BASE_URL}/orders`, {
      headers: { Authorization: `Bearer ${token}` }
    }).then(r => r.json())
};
```

### 2. Update Login Page

Add to your login form's submit handler:

```javascript
const loginForm = document.querySelector('form'); // Adjust selector as needed

loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const email = document.querySelector('input[type="email"]').value;
  const password = document.querySelector('input[type="password"]').value;

  try {
    const result = await API.login(email, password);

    if (result.success) {
      // Store token
      localStorage.setItem('token', result.token);
      localStorage.setItem('user', JSON.stringify(result.user));

      // Redirect to home or cart
      window.location.href = 'home.html';
    } else {
      alert('Login failed: ' + result.message);
    }
  } catch (error) {
    console.error('Login error:', error);
    alert('An error occurred during login');
  }
});
```

### 3. Update Header Cart Count

Add this to your header/navigation script:

```javascript
async function updateCartCount() {
  const token = localStorage.getItem('token');
  if (!token) {
    document.getElementById('cart-count').textContent = '0';
    return;
  }

  try {
    const result = await API.getCart(token);
    if (result.success) {
      const count = result.data.items.reduce((sum, item) => sum + item.qty, 0);
      document.getElementById('cart-count').textContent = count;
    }
  } catch (error) {
    console.error('Failed to update cart count:', error);
  }
}

// Update on page load and periodically
updateCartCount();
setInterval(updateCartCount, 30000); // Every 30 seconds
```

### 4. Update Cart Page

Replace the static cart items with:

```javascript
const API_BASE_URL = 'http://localhost:5000/api';

async function loadCart() {
  const token = localStorage.getItem('token');

  if (!token) {
    // Redirect to login if not authenticated
    window.location.href = 'login.html';
    return;
  }

  try {
    const result = await API.getCart(token);

    if (!result.success) {
      alert('Failed to load cart');
      return;
    }

    const { items, itemsTotal, shippingPrice, taxPrice, totalPrice } = result.data;
    const cartContainer = document.querySelector('.lg\\:col-span-2');

    // Clear existing items
    const cartItems = cartContainer.querySelectorAll('.cart-item');
    cartItems.forEach(item => item.remove());

    if (items.length === 0) {
      cartContainer.innerHTML = '<p class="text-gray-500">Your cart is empty</p>';
      return;
    }

    // Render cart items
    items.forEach(item => {
      const itemElement = document.createElement('div');
      itemElement.className = 'flex gap-4 bg-transparent py-4 justify-between border-b border-silver-gray dark:border-gray-800 items-center cart-item';
      itemElement.dataset.productId = item.product._id;

      itemElement.innerHTML = `
        <div class="flex items-center gap-4">
          <div class="bg-center bg-no-repeat aspect-square bg-cover rounded-lg h-24 w-24 flex-shrink-0" style="background-image: url('${item.product.image}');"></div>
          <div class="flex flex-1 flex-col justify-center">
            <p class="text-navy-blue dark:text-white text-base font-bold leading-normal">${item.product.name}</p>
            <p class="text-gray-600 dark:text-gray-400 text-sm font-normal leading-normal">Rs ${item.product.price}</p>
            <button class="text-left text-red-500 dark:text-red-400 text-xs font-medium mt-2 hover:underline remove-btn">Remove</button>
          </div>
        </div>
        <div class="flex flex-col items-end gap-2 shrink-0 ml-4">
          <div class="flex items-center gap-2 text-navy-blue dark:text-white border border-silver-gray dark:border-gray-700 rounded-full p-1">
            <button class="text-lg font-medium flex h-7 w-7 items-center justify-center rounded-full bg-gray-100 dark:bg-gray-700/50 hover:bg-gray-200 dark:hover:bg-gray-600 decrement-btn">-</button>
            <input type="number" value="${item.qty}" min="1" class="qty-input text-base font-medium w-6 p-0 text-center bg-transparent focus:outline-none"/>
            <button class="text-lg font-medium flex h-7 w-7 items-center justify-center rounded-full bg-gray-100 dark:bg-gray-700/50 hover:bg-gray-200 dark:hover:bg-gray-600 increment-btn">+</button>
          </div>
          <p class="text-navy-blue dark:text-white text-base font-bold leading-normal">Rs ${item.subtotal}</p>
        </div>
      `;

      cartContainer.appendChild(itemElement);
    });

    // Update totals display
    document.getElementById('subtotal').textContent = `Rs ${itemsTotal}`;
    document.getElementById('total').textContent = `Rs ${totalPrice}`;

    // Add event listeners
    attachCartEventListeners(token);
  } catch (error) {
    console.error('Error loading cart:', error);
    alert('Failed to load cart');
  }
}

async function attachCartEventListeners(token) {
  // Increment buttons
  document.querySelectorAll('.increment-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const input = btn.closest('.flex').querySelector('.qty-input');
      const newQty = parseInt(input.value) + 1;
      input.value = newQty;
      await updateCartItem(token, input);
    });
  });

  // Decrement buttons
  document.querySelectorAll('.decrement-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const input = btn.closest('.flex').querySelector('.qty-input');
      const newQty = parseInt(input.value) - 1;
      if (newQty > 0) {
        input.value = newQty;
        await updateCartItem(token, input);
      }
    });
  });

  // Remove buttons
  document.querySelectorAll('.remove-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const productId = btn.closest('.cart-item').dataset.productId;
      try {
        const result = await API.removeFromCart(token, productId);
        if (result.success) {
          loadCart(); // Reload cart
        }
      } catch (error) {
        console.error('Error removing item:', error);
      }
    });
  });
}

async function updateCartItem(token, input) {
  const productId = input.closest('.cart-item').dataset.productId;
  const qty = parseInt(input.value);

  try {
    const result = await API.addToCart(token, productId, qty);
    if (result.success) {
      loadCart(); // Reload cart to get updated totals
    }
  } catch (error) {
    console.error('Error updating cart:', error);
  }
}

// Load cart on page load
loadCart();
```

### 5. Update Checkout Page

Add to checkout form:

```javascript
const checkoutForm = document.querySelector('form'); // Adjust selector

checkoutForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const token = localStorage.getItem('token');
  if (!token) {
    alert('Please login first');
    window.location.href = 'login.html';
    return;
  }

  // Get form data
  const formData = new FormData(checkoutForm);
  const shippingAddress = {
    name: formData.get('name'),
    address: formData.get('address'),
    city: formData.get('city'),
    postalCode: formData.get('postal'),
    country: formData.get('country')
  };

  try {
    const result = await API.createOrder(token, shippingAddress, 'credit_card');

    if (result.success) {
      alert('Order placed successfully!');
      localStorage.removeItem('cart');
      window.location.href = 'home.html';
    } else {
      alert('Order failed: ' + result.message);
    }
  } catch (error) {
    console.error('Checkout error:', error);
    alert('An error occurred during checkout');
  }
});
```

---

## cURL Examples (Testing)

### Health Check
```bash
curl http://localhost:5000/api/health
```

### Signup
```bash
curl -X POST http://localhost:5000/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"name":"John","email":"john@test.com","password":"pass123"}'
```

### Login
```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@onewhite.com","password":"admin123456"}'
```

### Get Products
```bash
curl http://localhost:5000/api/products
curl "http://localhost:5000/api/products?search=handwash&limit=5"
```

### Get Cart (with token)
```bash
curl -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  http://localhost:5000/api/cart
```

### Add to Cart
```bash
curl -X POST http://localhost:5000/api/cart \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"productId":"507f1f77bcf86cd799439011","qty":2}'
```

### Create Order
```bash
curl -X POST http://localhost:5000/api/orders \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "shippingAddress": {
      "name": "John Doe",
      "address": "123 Main St",
      "city": "NYC",
      "postalCode": "10001",
      "country": "USA"
    },
    "paymentMethod": "credit_card"
  }'
```

---

## Database Schema

### Product
```javascript
{
  name: String (required),
  description: String,
  price: Number (required),
  image: String (required),
  category: String,
  stock: Number (default: 0),
  createdAt: Date,
  updatedAt: Date
}
```

### User
```javascript
{
  name: String (required),
  email: String (required, unique),
  password: String (hashed, required),
  cart: [
    { product: ObjectId, qty: Number }
  ],
  orders: [ObjectId],
  role: String (enum: ['user', 'admin']),
  createdAt: Date,
  updatedAt: Date
}
```

### Order
```javascript
{
  user: ObjectId (required),
  items: [
    { product: ObjectId, qty: Number, priceAtPurchase: Number }
  ],
  shippingAddress: {
    name: String,
    address: String,
    city: String,
    postalCode: String,
    country: String
  },
  paymentMethod: String,
  itemsTotal: Number,
  shippingPrice: Number,
  taxPrice: Number,
  totalPrice: Number,
  status: String (enum: ['pending', 'paid', 'shipped', 'delivered', 'cancelled']),
  createdAt: Date,
  updatedAt: Date
}
```

---

## Security Best Practices

✅ Passwords hashed with bcrypt (10 salt rounds)  
✅ JWT tokens with 7-day expiry  
✅ Environment variables for secrets  
✅ CORS restricted to frontend origin  
✅ Protected routes require valid JWT  
✅ Admin routes check user role  
✅ Input validation on all endpoints  
✅ Error messages don't leak sensitive info  

---

## Troubleshooting

### MongoDB Connection Error
- Check `MONGO_URI` in `.env`
- Ensure IP whitelist includes your machine on MongoDB Atlas
- Verify cluster is running

### CORS Error
- Make sure `FRONTEND_URL` in `.env` matches your frontend's origin
- Default is `http://localhost:3000`

### Token Expired
- Tokens expire after 7 days
- User needs to login again to get new token

### Products Not Loading
- Run `npm run seed` to populate initial data
- Check MongoDB connection

### Cart Not Syncing
- Clear browser cache
- Verify token is being sent in Authorization header
- Check browser console for errors

---

## Scripts

```bash
npm run dev    # Start with auto-reload (development)
npm start      # Start normally (production)
npm run seed   # Populate database with initial data
```

---

## Environment Variables Reference

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | 5000 | Server port |
| `MONGO_URI` | - | MongoDB connection string |
| `JWT_SECRET` | - | Secret key for signing JWTs |
| `JWT_EXPIRE` | 7d | Token expiration time |
| `FRONTEND_URL` | http://localhost:3000 | CORS origin |
| `NODE_ENV` | development | Environment mode |

---

## License

ISC

---

## Support

For issues or questions, check the cURL examples above and ensure:
1. Backend server is running (`npm run dev`)
2. MongoDB is connected
3. `.env` file is properly configured
4. Frontend is making requests to correct API URL
5. JWT tokens are included in Authorization header for protected routes

Happy coding! 🚀
