/**
 * FRONTEND INTEGRATION SNIPPETS
 * Copy these code blocks into your frontend HTML files
 * Adjust selectors based on your actual HTML structure
 */

// ============================================================================
// FILE 1: Create js/api.js in your frontend root
// ============================================================================

const API_BASE_URL = 'http://localhost:5000/api';

const API = {
  // ==================== AUTH ====================
  signup: (name, email, password) =>
    fetch(`${API_BASE_URL}/auth/signup`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password })
    }).then(r => r.json()),

  login: (email, password) =>
    fetch(`${API_BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    }).then(r => r.json()),

  // ==================== PRODUCTS ====================
  getProducts: (filters = {}) => {
    const params = new URLSearchParams(filters);
    return fetch(`${API_BASE_URL}/products?${params}`).then(r => r.json());
  },

  getProduct: (id) =>
    fetch(`${API_BASE_URL}/products/${id}`).then(r => r.json()),

  // ==================== CART ====================
  getCart: (token) =>
    fetch(`${API_BASE_URL}/cart`, {
      headers: { Authorization: `Bearer ${token}` }
    }).then(r => r.json()),

  addToCart: (token, productId, qty) =>
    fetch(`${API_BASE_URL}/cart`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({ productId, qty })
    }).then(r => r.json()),

  updateCart: (token, items) =>
    fetch(`${API_BASE_URL}/cart`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({ items })
    }).then(r => r.json()),

  removeFromCart: (token, productId) =>
    fetch(`${API_BASE_URL}/cart/${productId}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` }
    }).then(r => r.json()),

  // ==================== ORDERS ====================
  createOrder: (token, shippingAddress, paymentMethod) =>
    fetch(`${API_BASE_URL}/orders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({ shippingAddress, paymentMethod })
    }).then(r => r.json()),

  getOrders: (token) =>
    fetch(`${API_BASE_URL}/orders`, {
      headers: { Authorization: `Bearer ${token}` }
    }).then(r => r.json()),

  getOrder: (token, orderId) =>
    fetch(`${API_BASE_URL}/orders/${orderId}`, {
      headers: { Authorization: `Bearer ${token}` }
    }).then(r => r.json())
};

// ============================================================================
// FILE 2: Add this to login.html - Replace in <script> tag at end of body
// ============================================================================

// Paste api.js import first:
// <script src="js/api.js"></script>

document.addEventListener('DOMContentLoaded', () => {
  // Get form elements - ADJUST SELECTORS TO MATCH YOUR HTML
  const emailInput = document.querySelector('input[type="email"]');
  const passwordInput = document.querySelector('input[type="password"]');
  const loginButton = document.querySelector('button[type="submit"]');

  loginButton.addEventListener('click', async (e) => {
    e.preventDefault();

    const email = emailInput.value.trim();
    const password = passwordInput.value.trim();

    if (!email || !password) {
      alert('Please fill in all fields');
      return;
    }

    try {
      loginButton.disabled = true;
      loginButton.textContent = 'Logging in...';

      const result = await API.login(email, password);

      if (result.success) {
        // Store authentication token and user info
        localStorage.setItem('token', result.token);
        localStorage.setItem('user', JSON.stringify(result.user));

        // Update cart count in header
        updateCartCount();

        // Redirect to home or cart
        setTimeout(() => {
          window.location.href = 'home.html';
        }, 500);
      } else {
        alert('Login failed: ' + result.message);
      }
    } catch (error) {
      console.error('Login error:', error);
      alert('An error occurred during login. Check console.');
    } finally {
      loginButton.disabled = false;
      loginButton.textContent = 'Log In';
    }
  });

  // Allow Enter key to submit
  passwordInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') loginButton.click();
  });
});

// ============================================================================
// FILE 3: Add this to header/navigation (e.g., in cart.html or global script)
// ============================================================================

// Update cart count in header
async function updateCartCount() {
  const token = localStorage.getItem('token');
  const cartCountElement = document.getElementById('cart-count');

  if (!token) {
    if (cartCountElement) cartCountElement.textContent = '0';
    return;
  }

  try {
    const result = await API.getCart(token);
    if (result.success) {
      const count = result.data.items.reduce((sum, item) => sum + item.qty, 0);
      if (cartCountElement) cartCountElement.textContent = count;
    }
  } catch (error) {
    console.error('Failed to update cart count:', error);
  }
}

// Update cart count on page load
updateCartCount();

// Update periodically (every 30 seconds)
setInterval(updateCartCount, 30000);

// ============================================================================
// FILE 4: Add this to cart.html - Replace static cart items
// ============================================================================

// Paste api.js import first:
// <script src="js/api.js"></script>

document.addEventListener('DOMContentLoaded', async () => {
  const token = localStorage.getItem('token');

  if (!token) {
    // User not logged in, redirect to login
    window.location.href = 'login.html';
    return;
  }

  async function loadCart() {
    try {
      const result = await API.getCart(token);

      if (!result.success) {
        alert('Failed to load cart: ' + result.message);
        return;
      }

      const { items, itemsTotal, shippingPrice, taxPrice, totalPrice } = result.data;
      const cartContainer = document.querySelector('.lg\\:col-span-2');

      // Clear existing items
      const existingItems = cartContainer.querySelectorAll('.cart-item');
      existingItems.forEach(item => item.remove());

      if (items.length === 0) {
        cartContainer.innerHTML =
          '<div class="text-center py-8"><p class="text-gray-500 text-lg">Your cart is empty</p><a href="products.html" class="text-primary hover:underline mt-4 inline-block">Continue Shopping</a></div>';
        document.getElementById('subtotal').textContent = 'Rs 0';
        document.getElementById('total').textContent = 'Rs 0';
        return;
      }

      // Render each cart item
      items.forEach((item, index) => {
        const itemElement = document.createElement('div');
        itemElement.className =
          'flex gap-4 bg-transparent py-4 justify-between border-b border-silver-gray dark:border-gray-800 items-center cart-item';
        itemElement.dataset.productId = item.product._id;
        itemElement.dataset.index = index;

        const productImage = item.product.image.startsWith('http')
          ? item.product.image
          : item.product.image; // Keep as is or prepend path if needed

        itemElement.innerHTML = `
          <div class="flex items-center gap-4">
            <div class="bg-center bg-no-repeat aspect-square bg-cover rounded-lg h-24 w-24 flex-shrink-0"
                 style="background-image: url('${productImage}');"></div>
            <div class="flex flex-1 flex-col justify-center">
              <p class="text-navy-blue dark:text-white text-base font-bold leading-normal">${item.product.name}</p>
              <p class="text-gray-600 dark:text-gray-400 text-sm font-normal leading-normal">Rs ${item.product.price}</p>
              <button type="button" class="text-left text-red-500 dark:text-red-400 text-xs font-medium mt-2 hover:underline remove-btn">
                Remove
              </button>
            </div>
          </div>
          <div class="flex flex-col items-end gap-2 shrink-0 ml-4">
            <div class="flex items-center gap-2 text-navy-blue dark:text-white border border-silver-gray dark:border-gray-700 rounded-full p-1">
              <button type="button" class="text-lg font-medium flex h-7 w-7 items-center justify-center rounded-full bg-gray-100 dark:bg-gray-700/50 hover:bg-gray-200 dark:hover:bg-gray-600 decrement-btn">
                −
              </button>
              <input type="number" value="${item.qty}" min="1" class="qty-input text-base font-medium w-6 p-0 text-center bg-transparent focus:outline-none"/>
              <button type="button" class="text-lg font-medium flex h-7 w-7 items-center justify-center rounded-full bg-gray-100 dark:bg-gray-700/50 hover:bg-gray-200 dark:hover:bg-gray-600 increment-btn">
                +
              </button>
            </div>
            <p class="text-navy-blue dark:text-white text-base font-bold leading-normal">Rs ${item.subtotal}</p>
          </div>
        `;

        cartContainer.appendChild(itemElement);
      });

      // Update totals
      document.getElementById('subtotal').textContent = `Rs ${itemsTotal}`;
      document.getElementById('total').textContent = `Rs ${totalPrice}`;

      // Attach event listeners
      attachCartEventListeners();
    } catch (error) {
      console.error('Error loading cart:', error);
      alert('Failed to load cart. Please refresh the page.');
    }
  }

  function attachCartEventListeners() {
    // Increment buttons
    document.querySelectorAll('.increment-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        const input = btn.closest('.flex').querySelector('.qty-input');
        const newQty = parseInt(input.value) + 1;
        input.value = newQty;
        await updateCartItemQty(input);
      });
    });

    // Decrement buttons
    document.querySelectorAll('.decrement-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        const input = btn.closest('.flex').querySelector('.qty-input');
        const newQty = parseInt(input.value) - 1;
        if (newQty > 0) {
          input.value = newQty;
          await updateCartItemQty(input);
        }
      });
    });

    // Remove buttons
    document.querySelectorAll('.remove-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        const productId = btn.closest('.cart-item').dataset.productId;
        try {
          const result = await API.removeFromCart(token, productId);
          if (result.success) {
            loadCart(); // Reload cart
            updateCartCount(); // Update header count
          } else {
            alert('Failed to remove item: ' + result.message);
          }
        } catch (error) {
          console.error('Error removing item:', error);
          alert('An error occurred');
        }
      });
    });
  }

  async function updateCartItemQty(input) {
    const productId = input.closest('.cart-item').dataset.productId;
    const qty = parseInt(input.value);

    try {
      const result = await API.addToCart(token, productId, qty);
      if (result.success) {
        loadCart(); // Reload to get updated totals
        updateCartCount(); // Update header count
      } else {
        alert('Failed to update cart: ' + result.message);
      }
    } catch (error) {
      console.error('Error updating cart:', error);
      alert('An error occurred');
    }
  }

  // Load cart on page load
  loadCart();
});

// ============================================================================
// FILE 5: Add this to checkout.html - Process checkout form
// ============================================================================

// Paste api.js import first:
// <script src="js/api.js"></script>

document.addEventListener('DOMContentLoaded', () => {
  const token = localStorage.getItem('token');

  if (!token) {
    alert('Please login first');
    window.location.href = 'login.html';
    return;
  }

  const checkoutForm = document.querySelector('form'); // Adjust selector if needed

  if (checkoutForm) {
    checkoutForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      // ADJUST THESE SELECTORS TO MATCH YOUR FORM FIELDS
      const name = document.querySelector('input[name="name"]')?.value || '';
      const address = document.querySelector('input[name="address"]')?.value || '';
      const city = document.querySelector('input[name="city"]')?.value || '';
      const postalCode = document.querySelector('input[name="postal"]')?.value || '';
      const country = document.querySelector('input[name="country"]')?.value || '';

      if (!name || !address || !city || !postalCode || !country) {
        alert('Please fill in all shipping fields');
        return;
      }

      const shippingAddress = {
        name,
        address,
        city,
        postalCode,
        country
      };

      try {
        const submitButton = checkoutForm.querySelector('button[type="submit"]');
        submitButton.disabled = true;
        submitButton.textContent = 'Processing...';

        const result = await API.createOrder(token, shippingAddress, 'credit_card');

        if (result.success) {
          alert('Order placed successfully! Order ID: ' + result.data._id);
          localStorage.removeItem('cart');
          setTimeout(() => {
            window.location.href = 'home.html';
          }, 1000);
        } else {
          alert('Order failed: ' + result.message);
        }
      } catch (error) {
        console.error('Checkout error:', error);
        alert('An error occurred during checkout. Check console.');
      } finally {
        const submitButton = checkoutForm.querySelector('button[type="submit"]');
        submitButton.disabled = false;
        submitButton.textContent = 'Place Order';
      }
    });
  }
});

// ============================================================================
// HELPER: Check if user is logged in (call in any page)
// ============================================================================

function isUserLoggedIn() {
  return !!localStorage.getItem('token');
}

function getUserInfo() {
  const userJson = localStorage.getItem('user');
  return userJson ? JSON.parse(userJson) : null;
}

function logout() {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  window.location.href = 'login.html';
}

// ============================================================================
// USAGE EXAMPLES:
// ============================================================================

// Check login status:
// if (!isUserLoggedIn()) { window.location.href = 'login.html'; }

// Get user info:
// const user = getUserInfo();
// console.log(user.name, user.email);

// Logout:
// document.querySelector('.logout-btn').addEventListener('click', logout);
