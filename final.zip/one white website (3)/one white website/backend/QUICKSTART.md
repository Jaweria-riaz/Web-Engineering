# Quick Start Guide - One White Backend

## 🚀 5-Minute Setup

### Step 1: Get MongoDB Atlas URL
1. Go to https://www.mongodb.com/cloud/atlas
2. Sign up (free tier available)
3. Create a cluster → Create a database user → Get connection string
4. Replace `<password>` with your password

### Step 2: Configure Backend
```bash
cd backend
cp .env.example .env
```

Edit `.env` and paste your MongoDB URI:
```
MONGO_URI=mongodb+srv://username:password@cluster0.xxxxx.mongodb.net/onewhite?retryWrites=true&w=majority
```

### Step 3: Install & Run
```bash
npm install
npm run seed
npm run dev
```

Backend runs on `http://localhost:5000` ✅

### Step 4: Test API
```bash
curl http://localhost:5000/api/health
```

Should return: `{"status":"Backend is running"}`

---

## 📱 Frontend Integration (3 Steps)

### Step 1: Add API Config to Frontend

Create `js/api.js`:

```javascript
const API_BASE_URL = 'http://localhost:5000/api';

const API = {
  login: (email, password) =>
    fetch(`${API_BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    }).then(r => r.json()),

  getCart: (token) =>
    fetch(`${API_BASE_URL}/cart`, {
      headers: { Authorization: `Bearer ${token}` }
    }).then(r => r.json()),

  addToCart: (token, productId, qty) =>
    fetch(`${API_BASE_URL}/cart`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({ productId, qty })
    }).then(r => r.json()),

  removeFromCart: (token, productId) =>
    fetch(`${API_BASE_URL}/cart/${productId}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` }
    }).then(r => r.json()),

  createOrder: (token, shippingAddress, paymentMethod) =>
    fetch(`${API_BASE_URL}/orders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({ shippingAddress, paymentMethod })
    }).then(r => r.json())
};
```

### Step 2: Update Login Page

```html
<!-- In login.html, add this script at the end of body -->
<script src="js/api.js"></script>
<script>
  document.querySelector('button[type="submit"]').addEventListener('click', async (e) => {
    e.preventDefault();
    const email = document.querySelector('input[type="email"]').value;
    const password = document.querySelector('input[type="password"]').value;

    const result = await API.login(email, password);
    if (result.success) {
      localStorage.setItem('token', result.token);
      window.location.href = 'home.html';
    } else {
      alert('Login failed: ' + result.message);
    }
  });
</script>
```

### Step 3: Update Cart Page

```html
<!-- In cart.html, add this script at the end of body -->
<script src="js/api.js"></script>
<script>
  async function loadCart() {
    const token = localStorage.getItem('token');
    if (!token) return window.location.href = 'login.html';

    const result = await API.getCart(token);
    if (!result.success) return;

    const { items, itemsTotal, totalPrice } = result.data;
    const container = document.querySelector('.lg\\:col-span-2');

    // Clear and render items
    container.innerHTML = items.map(item => `
      <div class="flex gap-4 py-4 border-b cart-item" data-id="${item.product._id}">
        <img src="${item.product.image}" alt="${item.product.name}" class="h-24 w-24 object-cover rounded-lg" />
        <div class="flex-1">
          <p class="font-bold">${item.product.name}</p>
          <p class="text-sm text-gray-600">Rs ${item.product.price}</p>
          <button class="text-red-500 text-xs mt-2 remove-btn">Remove</button>
        </div>
        <div class="text-right">
          <input type="number" value="${item.qty}" class="w-12 qty-input" />
          <p class="font-bold">Rs ${item.subtotal}</p>
        </div>
      </div>
    `).join('');

    document.getElementById('subtotal').textContent = `Rs ${itemsTotal}`;
    document.getElementById('total').textContent = `Rs ${result.data.totalPrice}`;

    // Add event listeners
    document.querySelectorAll('.remove-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        const id = btn.closest('.cart-item').dataset.id;
        await API.removeFromCart(token, id);
        loadCart();
      });
    });

    document.querySelectorAll('.qty-input').forEach(input => {
      input.addEventListener('change', async () => {
        const id = input.closest('.cart-item').dataset.id;
        await API.addToCart(token, id, parseInt(input.value));
        loadCart();
      });
    });
  }

  loadCart();
</script>
```

---

## 🧪 Test Credentials

After running `npm run seed`:

**Admin Account:**
- Email: `admin@onewhite.com`
- Password: `admin123456`

**Test Customer:**
- Email: `customer@onewhite.com`
- Password: `customer123456`

---

## ✅ Verify Everything Works

1. **Backend Health:**
   ```bash
   curl http://localhost:5000/api/health
   ```

2. **Login:**
   ```bash
   curl -X POST http://localhost:5000/api/auth/login \
     -H "Content-Type: application/json" \
     -d '{"email":"admin@onewhite.com","password":"admin123456"}'
   ```
   Copy the `token` from response

3. **Get Products:**
   ```bash
   curl http://localhost:5000/api/products
   ```

4. **Get Cart (use token from login):**
   ```bash
   curl -H "Authorization: Bearer YOUR_TOKEN_HERE" \
     http://localhost:5000/api/cart
   ```

All working? ✅ Frontend ready to integrate!

---

## 📚 Full Documentation

See `README.md` for complete API documentation, database schemas, and troubleshooting.
